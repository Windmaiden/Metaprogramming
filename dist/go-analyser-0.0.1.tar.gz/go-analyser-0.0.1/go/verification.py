from typing import List

from go.objects.base import (
    GoBaseObjectType,
    GoIdentifier,
    GoString,
    GoNewLine,
)
from go.objects.base.go_space import GoSpace
from go.objects.go_file import GoFile


class VerificationError:
    """ Specify error at verification
    If not set Modificators,
    go_object will be replace to replace object when fix() call

    Attributes:
        REMOVE modificator for remove object only
        INSERT modificator for insert object only
        line return line with this error
        message return text error

    Methods:
        fix() trying to fix error
            if replace objects not set, ignore
    """
    REMOVE = 0
    INSERT = 1

    def __init__(self, name, file: GoFile, go_object: GoBaseObjectType = None,
                 replace: GoBaseObjectType = None, mode: int = None):
        self.name = name
        self.file = file
        self.object = go_object
        self._fix = replace
        self._mode = mode

    def fix(self) -> bool:
        """ Fix error by replace objects """
        if self._fix is None:
            return False

        index = self.file.objects.index(self.object)
        if self._mode != self.INSERT:
            del self.file.objects[index]
            self.object = None
        if self._mode != self.REMOVE:
            self.file.objects.insert(index, self._fix)
            self.object = self._fix
        return True

    @property
    def line(self) -> int:
        """ Get line location object """
        if self.object is None:
            return -1
        return self.file.get_line(self.object)

    @property
    def message(self) -> str:
        """ Message for logging """
        line = self.line if self.line != -1 else 'N/A'
        return f"{self.file.path} {line} {self.name}"


def lint_package_clause(file: GoFile):
    """ Lint package clause
    Verify:
        Count packages in file
        Package space
        Package name
    """
    objects = file.objects
    package_positions: List[int] = []
    for num, go_object in enumerate(objects):
        if str(go_object) == 'package':
            package_positions.append(num)

    if not package_positions:
        yield VerificationError('"package" not found', file)

    if len(package_positions) > 1:
        for package_position in package_positions:
            yield VerificationError('too many "package"', file,
                                    objects[package_position])

    package_position = package_positions[0]
    space: GoSpace = objects[package_position + 1]

    if not isinstance(space, GoSpace):
        yield VerificationError(f'Unexcepted "{space}"', file)

    if space.ident != 1:
        yield VerificationError('To many whitespace', file, space, GoSpace(' '))

    identifier = objects[package_position + 2]
    if not isinstance(identifier, GoIdentifier):
        yield VerificationError(f'Unexcepted package name "{identifier}"', file,
                                identifier)


def lint_import_clause(file: GoFile):
    """ lint import clause
    Verify:
        Many imports
        Unexcepted chars
        Spaces and format
    """
    objects = file.objects
    import_positions: List[int] = []
    for num, go_object in enumerate(objects):
        if str(go_object) == 'import':
            import_positions.append(num)

    if not import_positions:
        return

    if len(import_positions) > 1:
        for import_position in import_positions:
            yield VerificationError('too many "import"', file,
                                    objects[import_position])

    import_position = import_positions[0]
    space: GoSpace = objects[import_position + 1]

    if not isinstance(space, GoSpace):
        yield VerificationError(f'Unexcepted "{space}"', file)

    if space.ident != 1:
        yield VerificationError('To many whitespace', file, space, GoSpace(' '))

    open_bracket = objects[import_position + 2]
    if str(open_bracket) != '(':
        yield VerificationError(f'Unexcepted "{open_bracket}"', file,
                                open_bracket)
        return

    # Check imports in brackets
    pos = import_position + 3
    while str(objects[pos]) != ')':
        go_object = objects[pos]

        for class_name in [GoNewLine, GoSpace, GoString]:
            if isinstance(go_object, class_name):
                break
        else:
            yield VerificationError(f'Unexcepted "{go_object}"', file,
                                    go_object)

        if isinstance(go_object, GoSpace):
            if isinstance(objects[pos - 1], GoNewLine) and go_object.ident != 4:
                yield VerificationError(f'Bad space', file, go_object,
                                        GoSpace('\t'))
            elif isinstance(objects[pos + 1], GoNewLine):
                yield VerificationError(f'No need space', file, go_object,
                                        mode=VerificationError.REMOVE)
                pos -= 1
        pos += 1


def lint_brackets_identation(file: GoFile):
    """ Verify identation in brackets """
    ident = []
    pos = 0
    while pos < len(file.objects) - 1:
        go_object = file.objects[pos]

        if str(go_object) in "({[":
            offset = 1
            while True:
                next_object = file.objects[pos + offset]
                if isinstance(next_object, GoNewLine):
                    i = ident[-1] if ident else 0
                    ident.append(i + 4)
                    break
                elif not isinstance(next_object, GoSpace):
                    ident.append(file.get_line_pos(go_object))
                    break
                offset += 1

        if str(go_object) in ")}]":
            ident.pop()

        next_object = file.objects[pos + 1]
        need_ident = (
            isinstance(file.objects[pos - 1], GoNewLine) and
            not isinstance(go_object, GoNewLine) and
            str(next_object) not in {'case', 'default'}  # switch case
        )
        if need_ident:
            if isinstance(go_object, GoSpace):
                if str(next_object) not in "}])":
                    if ident and go_object.ident != ident[-1]:
                        yield VerificationError("Bad space", file, go_object,
                                                GoSpace(ident[-1]))
                else:
                    if ident and go_object.ident != ident[-2]:
                        yield VerificationError("Bad space", file, go_object,
                                                GoSpace(ident[-2]))
            elif ident and not isinstance(next_object, GoNewLine):
                yield VerificationError("Not space", file, go_object,
                                        GoSpace(ident[-1]),
                                        VerificationError.INSERT)

        pos += 1


def lint_lines(file: GoFile):
    """ Check empty lines """
    for num in range(1, len(file.objects[1:-1]), 1):
        empty_line = (
            isinstance(file.objects[num], GoNewLine) and
            isinstance(file.objects[num - 1], GoNewLine) and
            isinstance(file.objects[num + 1], GoNewLine)
        )
        if empty_line:
            yield VerificationError("Too many empty lines", file,
                                    file.objects[num],
                                    mode=VerificationError.REMOVE)
